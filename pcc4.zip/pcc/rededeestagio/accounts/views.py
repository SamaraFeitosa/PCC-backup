from django.shortcuts import render
from django.http import HttpResponseRedirect
from django.shortcuts import render
from django.contrib.auth.forms import UserCreationForm
from django.urls import reverse_lazy
from django.views import generic
from .models import User
#from .forms import CustomUserForm
#from .forms import CustomUserCreationForm

class SingUp(generic.CreateView):

    form_class = UserCreationForm
    success_url = reverse_lazy('login')
    template_name = 'registration/cadastrarempresa.html'

#def register(request):
#    return form 

#   def criar (request):
# 
#       if request.method == "POST":
#           form = CustomUserCreationForm(request.POST)
#   
#           if form.is_valid():
#               form.save()
#               return reverse("/accounts/login")
#
#       else:
#          form = CustomUserCReationForm()
#       return render(request, 'registracion/login', {'form': form})