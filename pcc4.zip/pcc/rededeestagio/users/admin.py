import email
from django.contrib import admin
from django.contrib.auth import admin as auth_admin
from django.contrib import admin
from .models import Discente, Empresa
from .forms import UserChangeForm, UserCreationForm
from .models import User
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin

class DiscenteInline(admin.StackedInline):
    model = Discente
    can_delete = False
    verbose_name = 'Discente'

class EmpresaInline(admin.StackedInline):
    model = Empresa
    can_delete = False
    verbose_name = 'Empresa'

class UserAdmin(BaseUserAdmin):
    inlines = (DiscenteInline, EmpresaInline)


@admin.register(User)
class UserAdmin(auth_admin.UserAdmin):
    form = UserChangeForm
    add_form = UserCreationForm
    model = User

@admin.register(Discente)
class DiscenteAdmin(admin.ModelAdmin):
    model = Discente
    list_display = ('user', 'matricula',)

@admin.register(Empresa)
class EmpresaAdmin(admin.ModelAdmin):
    model = Empresa
    list_display = ('user', 'CNPJ',)

# Re-register UserAdmin
admin.site.unregister(User)
admin.site.register(User, UserAdmin)