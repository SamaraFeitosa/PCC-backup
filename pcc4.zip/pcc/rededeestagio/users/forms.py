from django.contrib.auth import forms
from .models import Discente, User
from .models import Discente


class UserChangeForm(forms.UserChangeForm):
    class Meta(forms.UserChangeForm.Meta):
        model = User

class UserCreationForm(forms.UserCreationForm):
    class Meta(forms.UserCreationForm.Meta):
        model = User

class UserChangeForm(forms.UserChangeForm):
    class Meta:
        model = Discente
        fields = ("__all__")

class UserCreationForm(forms.UserCreationForm):
    class Meta(forms.UserCreationForm.Meta):
        model = Discente
        fields = ("__all__")