from django.db import models
from django.contrib.auth.models import AbstractUser
from django.contrib.auth.models import User


class User(AbstractUser):
    pass

class Discente(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    matricula = models.CharField('Matrícula', max_length=12)
    nome = models.CharField('Nome', max_length=50)
    cidade = models.CharField('Cidade', max_length=12)
    turma = models.CharField('Turma', max_length=12)
    serie = models.IntegerField('Série')
    telefone = models.IntegerField('Telefone', null = True)
    

    def __str__(self):
        return self.user.username
    def __str__(self):
        return self.nome
    def __str__(self):
        return self.cidade
    def __str__(self):
        return self.turma

    
    


class Empresa(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    razaosocial = models.CharField('Razão Social', max_length=70)
    CNPJ = models.IntegerField()
    imagem = models.ImageField('Imagem',null = False)
    contato = models.IntegerField('Contato')
    rua = models.CharField('Rua',max_length=200)
    numero = models.IntegerField('Número')
    bairro = models.CharField('Bairro',max_length=200)
    CEP= models.IntegerField()

    def __str__(self):
        return self.user.username
    def __str__(self):
        return self.razaosocial
    def __str__(self):
        return self.imagem
    def __str__(self):
        return self.rua
    def __str__(self):
        return self.bairro
    