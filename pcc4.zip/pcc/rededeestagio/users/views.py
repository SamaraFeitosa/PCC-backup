
from django.shortcuts import render
from django.http import HttpResponseRedirect
from .forms import UserChangeForm, UserCreationForm

def empresa(request):
  
    if request.method == "POST":
        form = UserChangeForm(request.POST)
        add_form = UserCreationForm(request.POST)
    
        if form.is_valid():
            form.save()
            return HttpResponseRedirect("/post")

    else:
        form = UserChangeForm()
        add_form = UserChangeForm()
    
    return render(request, 'users/register.html', {'form': form, 'add_form': add_form})
