import email
from pickle import TRUE
from django.contrib.auth.models import AbstractUser
from django.db import models


class Empresa(models.Model):
    nome = models.CharField(max_length=200)
    email = models.EmailField()
    CNPJ = models.IntegerField( primary_key=TRUE)
    senha = models.IntegerField()
    contato = models.IntegerField()
    rua = models.CharField(max_length=200)
    numero = models.IntegerField()
    bairro = models.CharField(max_length=200)
    CEP= models.IntegerField()

