from django.http import HttpResponse
from django.shortcuts import render
from django.contrib.auth.forms import UserCreationForm
from django.urls import reverse_lazy
from django.views import generic
from django.contrib.auth.decorators import login_required
from .models import Empresa
from django.contrib import messages

@login_required
def postagem(request):
    
    return render(request,'/usuario/postagem.html', {})

def index(request):

    return render(request,'usuario/cursos.html',{})

