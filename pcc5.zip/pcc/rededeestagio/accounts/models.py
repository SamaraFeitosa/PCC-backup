from django.db import models
from pickle import TRUE
from django.contrib.auth import get_user_model


class Empresa(models.Model):
    userEmpresa = models.OneToOneField(get_user_model(), on_delete=models.CASCADE, verbose_name= "Usuário")
    nome = models.CharField('Razão Social', max_length=120, null=True)
    CNPJ = models.IntegerField( null=True)
    contato = models.IntegerField(null=True)
    rua = models.CharField(max_length=120, null=True)
    numero = models.IntegerField(null=True)
    bairro = models.CharField(max_length=120, null=True)
    CEP= models.IntegerField(null=True)
    e_empresa = models.BooleanField(auto_created=True, verbose_name="É empresa")

    def __str__(self):
        return self.nome
    def __str__(self):
        return self.rua
    def __str__(self):
        return self.bairro



    