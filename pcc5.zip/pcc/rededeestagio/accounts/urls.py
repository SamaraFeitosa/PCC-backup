from django.urls import path

from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('cadastrar/', views.cadastrarUserEmpresa, name='cadastrarUserEmpresa'),
    path('cadastrarempresa/', views.cadastrarEmpresa, name='cadastrarEmpresa'),
]