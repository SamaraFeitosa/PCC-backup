from django.contrib import admin
from .models import Postagem
admin.site.register(Postagem)
