from django.urls import path
#from users.views import Update, UserCreate
from . import views
from django.contrib.auth import views as auth_views

urlpatterns = [
    path('login/', auth_views.LoginView.as_view(
            template_name = 'users/login.html'
        ), name="login"),
    path('logout/', auth_views.LogoutView.as_view(), name="logout"),
    path('', views.index, name="index" ),
    path('home/', views.home, name="home"),
    #path('criar/', views.cursos, name = 'cursos'),
    #path('perfil/<int:user_id>/', views.perfil, name = "perfil"),
  #  path('update/<slug:pk>/', Update.as_view(), name='update'),

]