from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.views.generic.edit import CreateView
from django.urls import reverse_lazy
from django.http import HttpResponseRedirect



@login_required
def home(request):
    
    return render(request,'users/home.html', {})
    
@login_required
def index(request):

    return render(request,'users/cursos.html',{})


#@login_required
#def perfil(request, user_id):
#    perfil = User.objects.get(pk = user_id)
    
#    return render(request,'users/perfil.html',{'perfil': perfil, 'user_id': user_id})


#class Update(UpdateView):
#    model = User #model
#    fields = ['username', 'CNPJ', 'email','contato', 'rua', 'numero','bairro', 'CEP'] # fields / if you want to select all fields, use "__all__"
#    template_name = 'users/update.html' # templete for updating
#    success_url ='/post' # posts list url
